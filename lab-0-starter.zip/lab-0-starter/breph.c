#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define FAIL(s) { fail(s); exit(EXIT_FAILURE); }
#define MEM_SZ 30000
#define min(a,b) (((a) < (b)) ? (a) : (b))

void fail(char* errorMessage) {
  printf("%s", errorMessage);
}

void usage() {
  printf("\nUsage: ./breph [-d] <file>\n");
  printf("\nBreph is a Turing machine simulator, with a C-like pointer syntax.\nUnlike a real Turing machine, Breph has a finite tape consisting\nof 30,000 one-byte cells.  The read/write head is initially at\nindex 0. In the syntax below, <e> denotes an arbitrary expression.\n");
  printf("\nBreph syntax:\n");
  printf("\n  Input\n");
  printf("  i\tPrompt for a character of input and return it.\n");
  printf("  n\tPrompt for a character of input, interpret it as a number,\n\tand return it as a number.\n");
  printf("\n  Output\n");
  printf("  <e>o\tPrint the result of <e> as a character and return <e>.\n");
  printf("  <e>#\tPrint the result of <e> as a numeric character and return\n\tthe ASCII value of <e>.\n");
  printf("\n  Math\n");
  printf("  <e>+\tAdd one to the result of <e> and return it.\n");
  printf("  <e>-\tSubtract one from the result of <e> and return it.\n");
  printf("\n  Pointer operations\n");
  printf("  *\tReturn the contents of the current cell.\n");
  printf("  &\tReturn the location of the current cell.\n");
  printf("\n  State\n");
  printf("  <e>.\tStore the result of <e> in the current cell and return <e>.\n");
  printf("  <e>!\tChange the location of the current cell to the result of\n\t<e> and return <e>.\n");
  printf("  \\n\tA new line resets the return value to nothing, otherwise\n\tthe return value is the result of the preceding\n\texpression.\n");
  printf("\n  Control flow\n");
  printf("  j\tIf the current cell is zero, jump to the operation after the\n\tnext u, returning zero.\n");
  printf("  u\tIf the current cell is nonzero, jump to the operation before\n\tthe previous j, returning the current cell.\n");
  printf("\n  Debugging\n");
  printf("  -d\tWhen the optional debug flag is given, Breph will print out\n\tall machine state and wait for the user to press the [Enter]\n\tkey.\n");
  printf("\nExample:\n");
  printf("\t$ ./breph program.eph\n");
  printf("\n");
  printf("Version 1.0, Feb 2, 2022.");
  printf("\n");
  
  exit(EXIT_FAILURE);
}
 
typedef enum operation {
  ICHAR,
  INUM,
  OCHAR,
  ONUM,
  INCREMENT,
  DECREMENT,
  STORE,
  STOREPTR,
  DEREFERENCE,
  ADDRESSOF,
  JUMP,
  UNJUMP,
  NEWLINE,
  NOP
} op_t;

char* op_symbol(op_t op) {
  switch(op) {
    case ICHAR:
      return "ICHAR";
    case INUM:
      return "INUM";
    case OCHAR:
      return "OCHAR";
    case INCREMENT:
      return "INCREMENT";
    case DECREMENT:
      return "DECREMENT";
    case STORE:
      return "STORE";
    case STOREPTR:
      return "STOREPTR";
    case DEREFERENCE:
      return "DEREFERENCE";
    case ADDRESSOF:
      return "ADDRESSOF";
    case JUMP:
      return "JUMP";
    case UNJUMP:
      return "UNJUMP";
    case NEWLINE:
      return "NEWLINE";
    case NOP:
      return "NOP";
    default:
      FAIL("Unknown operation.");
  }
}

typedef struct result {
  op_t  type;
  int   result;
} res_t;

res_t retval(op_t type, int result) {
  res_t res;
  res.type = type;
  res.result = result;
  return res;
}

void dump_state(int* mem, res_t rv, int ptr) {
  // what set memory cell has the largest index?
  int max = 0;
  for (int i = 0; i < MEM_SZ; i++) {
    if (mem[i] != 0) {
      max = i;
    }
  }
  max = max > 3 ? max : 3;

  // draw memory
  char top[(max+1)*4+2];
  char mid[(max+1)*4+2];
  char bot[(max+1)*4+2];
  memset(top, 0, (max+1)*4+2);
  memset(mid, 0, (max+1)*4+2);
  memset(bot, 0, (max+1)*4+2);
  for (int i = 0; i < (max+1); i++) {
    // bars
    for (int j = 0; j < 4; j++) {
      int k = i*4+j;
      top[k] = '-';
      bot[k] = '-';
    }

    // number
    char num[4] = {0};
    int val = min(mem[i], 999);
    snprintf(num, 4, "%.3d", val);
    mid[i*4] = '|';
    for (int j = 0; j < strlen(num); j++) {
      int k = i*4+j;
      mid[k+1] = num[j];
    }
  }
  top[sizeof(top)-2] = '-';
  mid[sizeof(mid)-2] = '|';
  bot[sizeof(bot)-2] = '-';

  // print it
  printf("%s\n%s\n%s\n", top, mid, bot);
  printf("PTR: %d\n", ptr);
  printf("RET: %s, %d\n", op_symbol(rv.type), rv.result);
}

/**
 * Parse a line of Breph code, returning the appropriate
 * AST node.  Recurses if there is more than one Breph
 * character in the line.
 */
op_t parse_char(char c) {
  switch (c) {
    case ' ':
      return NOP;
    case 'i':
      return ICHAR;
    case 'n':
      return INUM;
    case 'o':
      return OCHAR;
    case '#':
      return ONUM;
    case '+':
      return INCREMENT;
    case '-':
      return DECREMENT;
    case '.':
      return STORE;
    case '!':
      return STOREPTR;
    case '*':
      return DEREFERENCE;
    case '&':
      return ADDRESSOF;
    case 'j':
      return JUMP;
    case 'u':
      return UNJUMP;
    case '\r':
    case '\n':
      return NEWLINE;
    default:
    {
      char* msg = "ERROR: Unknown command '%c'.\n";
      char buf[strlen(msg) + 1];
      snprintf(buf, sizeof(buf), msg, c);
      FAIL(buf);
    }
  }
}

int eval(const op_t* operations, long len, int* const mem, bool debug) {
  // initalize ptr
  int ptr = 0;
  
  // initialize retval
  res_t rv = retval(NOP, 0);
  
  for (int i = 0; i < len; i++) {
    start_eval:;

    if (debug) {
      char* op_name = op_symbol(operations[i]);
      printf("Evaluating step %d, op %s\n", i, op_name);
      dump_state(mem, rv, ptr);
      getchar();
    }
    
    switch(operations[i]) {
      case NOP:
        break; // do nothing
      case ICHAR:
      {
        rv = retval(ICHAR, getchar());
        break;
      }
      case INUM:
      {
        char c = getchar();
        rv = retval(INUM, atoi(&c));
        break;
      }
      case OCHAR:
      {
        // only print if the result is not NOP
        if (rv.type != NOP) {
          printf("%c", rv.result);
        }
        break;
      }
      case ONUM:
      {
        // only print if the result is not NOP
        if (rv.type != NOP) {
          char c[2] = {0};
          snprintf(c, 2, "%d", rv.result);
          printf("%s", c);
          rv = retval(ONUM, c[0]);
        }
        break;
      }
      case INCREMENT:
      {
        if (rv.type == NOP) {
          FAIL("ERROR: Cannot increment nothing.\n");
        }
        rv = retval(INCREMENT, rv.result + 1);
        break;
      }
      case DECREMENT:
      {
        if (rv.type == NOP) {
          FAIL("ERROR: Cannot decrement nothing.\n");
        }
        rv = retval(INCREMENT, rv.result - 1);
        break;
      }
      case STORE:
      {
        if (rv.type == NOP) {
          FAIL("ERROR: Cannot store nothing.\n");
        }
        if (ptr < 0 || ptr >= len) {
          FAIL("ERROR: Cannot store out of bounds.\n");
        }
        mem[ptr] = rv.result;
        break;
      }
      case STOREPTR:
      {
        if (rv.type == NOP) {
          FAIL("ERROR: Cannot store nothing.\n");
        }
        if (rv.result < 0 || rv.result >= len) {
          FAIL("ERROR: Cannot move data pointer out of bounds.\n");
        }
        ptr = rv.result;
        break;
      }
      case DEREFERENCE:
      {
        if (ptr < 0 || ptr >= len) {
          FAIL("ERROR: Cannot dereference out of bounds.\n");
        }
        rv = retval(DEREFERENCE, mem[ptr]);
        break;
      }
      case ADDRESSOF:
      {
        if (ptr < 0 || ptr >= len) {
          FAIL("ERROR: Cannot take address of out of bounds data pointer.\n");
        }
        rv = retval(DEREFERENCE, ptr);
        break;
      }
      case JUMP:
      {
        if (ptr < 0 || ptr >= len) {
          FAIL("ERROR: Cannot jump from out of bounds.\n");
        }
        if (mem[ptr] == 0) {
          // search for the next u
          for (int j = i; j < len - 1; j++) {
            if (operations[j] == UNJUMP) {
              i = j + 1;
              rv = retval(JUMP, 0);
              goto start_eval;
            }
          }
          FAIL("ERROR: No u after j found.\n");
        }
        break;
      }
      case UNJUMP:
      {
        if (ptr < 0 || ptr >= len) {
          FAIL("ERROR: Cannot unjump from out of bounds.\n");
        }
        if (mem[ptr] != 0) {
          // search for the previous j
          for (int j = i; j > 1; j--) {
            if (operations[j] == JUMP) {
              i = j - 1;
              rv = retval(UNJUMP, mem[ptr]);
              goto start_eval;
            }
          }
          FAIL("ERROR: No j before u found.\n");
        }
        break;
      }
      case NEWLINE:
      {
        rv = retval(NOP, 0);
        break;
      }
      default: // do nothing
        continue;
    }
  }
  // return the current value under the pointer
  return mem[ptr];
}
 
long file_len(FILE* f) {
  fseek(f, 0L, SEEK_END);
  long len = ftell(f);
  rewind(f);
  return len;
}
 
int main(int argc, char** argv) {
  if (argc != 2 && argc != 3) {
    usage();
  }
  
  char* fname = argc == 2 ? argv[1] : argv[2];
  bool debug = argc == 3;
  
  // initialize main memory
  int mem[MEM_SZ] = {0};
  
  // open the given file
  FILE* f = fopen(fname, "r");
  
  // how long is the program?
  long len = file_len(f);
  
  // allocate enough storage for program
  op_t operations[len];
  
  // parse program
  for (int i = 0; i < len; i++) {
    char c = getc(f);
    if (c == EOF) FAIL("Unexpected end of file.");
    operations[i] = parse_char(c);
  }
  
  // evaluate program
  int final = eval(operations, len, mem, debug);
  
  // flush output
  printf("\n");
  
  return final; // TODO: return the value under ptr
}

